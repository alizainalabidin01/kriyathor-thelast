"use strict";
exports.id = 473;
exports.ids = [473];
exports.modules = {

/***/ 473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Footer/index.js



const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: "shadow-md",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col bg-gray-100 p-8 sm:flex-row",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-5 items-center text-center sm:gap-10 sm:items-start sm:flex-row",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mx-8",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/image/logo.png",
              className: "w-24"
            })
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "text-sm text-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
            className: "font-bold uppercase",
            children: " Follow "
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
            className: "flex-col gap-4 sm:flex-row items-center",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
              className: "flex gap-2 pb-2",
              children: [" ", /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fab fa-facebook"
              }), " Kriyathor Gift "]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
              className: "flex gap-2 pb-2",
              children: [" ", /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fab fa-instagram"
              }), " kriyathor "]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
              className: "flex gap-2 pb-2",
              children: [" ", /*#__PURE__*/jsx_runtime_.jsx("i", {
                className: "fab fa-twitter"
              }), " kriyathor "]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "text-sm text-center sm:text-left",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
            className: "font-bold uppercase",
            children: " Help "
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
            className: "flex-col text-center items-start sm:text-left sm:items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
              className: "pb-2",
              children: " About Us "
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              className: "pb-2",
              children: " Term & Policy "
            }), /*#__PURE__*/jsx_runtime_.jsx("li", {
              className: "pb-2",
              children: " FAQs "
            })]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-auto mt-10 text-sm sm:mt-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
          className: "font-bold uppercase text-center",
          children: " Payment Methods "
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex justify-center mt-5 gap-2 sm:gap-7",
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/image/bca.png",
            className: "w-auto h-5"
          }), /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/image/bri.png",
            className: "w-auto h-5"
          }), /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/image/dana.png",
            className: "w-auto h-5"
          }), /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/image/line.png",
            className: "w-auto h-5"
          }), /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/image/shopeepay.png",
            className: "w-auto h-5"
          })]
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex flex-col justify-center bg-gray-100 py-8",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-col justify-center bg-gray-100 pt-4 border-solid border-t-4 border-gray-50 mx-4 lg:flex-row",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-center",
          children: " \xA9KRIYATHOR 2021 "
        })
      })
    })]
  });
};

/* harmony default export */ const components_Footer = (Footer);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(505);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
;// CONCATENATED MODULE: ./components/Navbar/index.js






function Navbar() {
  const {
    0: isOpen,
    1: setIsOpen
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
    className: " shadow-sm w-full z-10 bg-white",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-full",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row items-center h-20 w-full",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center mx-20 justify-between w-full",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex justify-center items-center flex-shrink-0 ",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/image/logo-text.png",
              className: "h-5 sm:h-8"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "hidden md:block",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "ml-10 flex items-baseline space-x-4",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  className: "cursor-pointer hover:bg-gray-500 text-black hover:text-white px-3 py-2 rounded-md text-sm font-medium",
                  children: "Home"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/product",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  className: "cursor-pointer hover:bg-gray-500 text-black hover:text-white px-3 py-2 rounded-md text-sm font-medium",
                  children: "Product"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/about",
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  className: "cursor-pointer hover:bg-gray-500 text-black hover:text-white px-3 py-2 rounded-md text-sm font-medium",
                  children: "About Us"
                })
              })]
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mr-10 flex md:hidden ",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
            onClick: () => setIsOpen(!isOpen),
            type: "button",
            className: "bg-black inline-flex items-center justify-center p-2 rounded-md text-white  hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-white",
            "aria-controls": "mobile-menu",
            "aria-expanded": "false",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "sr-only",
              children: "Open main menu"
            }), !isOpen ? /*#__PURE__*/jsx_runtime_.jsx("i", {
              className: "fas fa-bars md:fa-2x"
            }) : /*#__PURE__*/jsx_runtime_.jsx("i", {
              className: "fas fa-times md:fa-2x"
            })]
          })
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
      show: isOpen,
      enter: "transition ease-out duration-100 transform",
      enterFrom: "opacity-0 scale-95",
      enterTo: "opacity-100 scale-100",
      leave: "transition ease-in duration-100 transform",
      leaveFrom: "opacity-100 scale-100",
      leaveTo: "opacity-0 scale-95",
      children: ref => /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "md:hidden text-center",
        id: "mobile-menu",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          ref: ref,
          className: "bg-white px-2 pb-3 space-y-1 sm:px-3",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "cursor-pointer hover:bg-gray-500 text-black hover:text-white block px-3 py-2 rounded-md text-base font-medium",
              children: "Home"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/product",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "cursor-pointer hover:bg-gray-500 text-black hover:text-white block px-3 py-2 rounded-md text-base font-medium",
              children: "Product"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/about",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "cursor-pointer hover:bg-gray-500 text-black hover:text-white block px-3 py-2 rounded-md text-base font-medium",
              children: "About Us"
            })
          })]
        })
      })
    })]
  });
}

/* harmony default export */ const components_Navbar = (Navbar);
;// CONCATENATED MODULE: ./components/Layout/index.js






const MainLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_Navbar, {}), children, /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
  });
};

/* harmony default export */ const Layout = (MainLayout);

/***/ })

};
;