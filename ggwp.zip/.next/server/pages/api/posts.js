"use strict";
(() => {
var exports = {};
exports.id = 223;
exports.ids = [223];
exports.modules = {

/***/ 959:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ posts)
});

;// CONCATENATED MODULE: external "serverless-mysql"
const external_serverless_mysql_namespaceObject = require("serverless-mysql");
var external_serverless_mysql_default = /*#__PURE__*/__webpack_require__.n(external_serverless_mysql_namespaceObject);
;// CONCATENATED MODULE: ./lib/db.js

const db = external_serverless_mysql_default()({
  config: {
    host: 'localhost',
    database: 'scraper',
    user: 'root',
    password: ''
  }
});
async function sql_query(query_string, value = []) {
  try {
    const results = await db.query(query_string, value);
    await db.end();
    return results;
  } catch (e) {
    throw Error(e.message);
  }
} //kriyathorstikom  (45l4M8R@JaGha
;// CONCATENATED MODULE: ./pages/api/posts.js


const handler = async (_, res) => {
  try {
    const results = await sql_query('SELECT * FROM kriyathor');
    return res.json(results);
  } catch (e) {
    res.status(500).json({
      message: e.message
    });
  }
};

/* harmony default export */ const posts = (handler);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(959));
module.exports = __webpack_exports__;

})();